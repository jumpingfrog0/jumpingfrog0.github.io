//
//  BarSDK.m
//  HelloSDK
//
//  Created by sheldon on 03/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import "BarSDK.h"

@implementation BarSDK
- (void)bar {
    NSLog(@"bar~~bar");
}
@end
