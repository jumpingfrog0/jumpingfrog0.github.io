//
//  FooSDK.m
//  HelloSDK
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import "FooSDK.h"
#import <UIKit/UIKit.h>

@implementation FooSDK
- (void)foo {
    NSLog(@"%@", @"foo~~~foo");
}

- (void)getLoveImage {
    UIImage *loveImage = [UIImage imageNamed:@"../HelloSDK.bundle/love"];
    NSLog(@"%@", NSStringFromCGSize(loveImage.size));
}
@end
