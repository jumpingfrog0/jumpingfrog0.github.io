//
//  HelloSDK.h
//  HelloSDK
//
//  Created by sheldon on 03/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HelloSDK.
FOUNDATION_EXPORT double HelloSDKVersionNumber;

//! Project version string for HelloSDK.
FOUNDATION_EXPORT const unsigned char HelloSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloSDK/PublicHeader.h>

#import "FooSDK.h"
#import "BarSDK.h"
#import "UIView+Foo.h"


