//
//  FooSDK.h
//  HelloSDK
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FooSDK : NSObject
- (void)foo;
- (void)getLoveImage;
@end
