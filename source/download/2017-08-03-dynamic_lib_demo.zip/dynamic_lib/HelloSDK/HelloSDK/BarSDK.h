//
//  BarSDK.h
//  HelloSDK
//
//  Created by sheldon on 03/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BarSDK : NSObject
- (void)bar;
@end
