//
//  HelloLib.m
//  HelloLib
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import "HelloLib.h"

@implementation HelloLib
- (void)hello {
    NSLog(@"%@", @"hello lib");
}
@end
