//
//  UIView+Bar.h
//  HelloLib
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Bar)
- (void)bar;
@end
