//
//  FooLib.m
//  HelloLib
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import "FooLib.h"
#import <UIKit/UIKit.h>

@implementation FooLib
- (void)foo {
    NSLog(@"%@", @"foo~~~foo");
}

- (void)getLoveImage {
    UIImage *loveImage = [UIImage imageNamed:@"../HelloLib.bundle/love"];
    NSLog(@"%@", NSStringFromCGSize(loveImage.size));
}
@end
