//
//  FooLib.h
//  HelloLib
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FooLib : NSObject
- (void)foo;
- (void)getLoveImage;
@end
