//
//  HelloLib.h
//  HelloLib
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HelloLib : NSObject
- (void)hello;
@end
