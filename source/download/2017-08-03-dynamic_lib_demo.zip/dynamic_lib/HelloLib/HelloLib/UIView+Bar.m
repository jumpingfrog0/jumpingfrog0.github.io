//
//  UIView+Bar.m
//  HelloLib
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import "UIView+Bar.h"
#import <Foundation/Foundation.h>

@implementation UIView (Bar)
- (void)bar {
    NSLog(@"%@", @"bar~~bar");
}
@end
