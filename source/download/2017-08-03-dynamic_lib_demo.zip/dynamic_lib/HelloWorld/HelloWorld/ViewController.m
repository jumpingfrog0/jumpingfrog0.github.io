//
//  ViewController.m
//  HelloWorld
//
//  Created by sheldon on 02/08/2017.
//  Copyright © 2017 jumpingfrog0. All rights reserved.
//

#import "ViewController.h"
#import "HelloLib.h"
#import "FooLib.h"
#import "UIView+Bar.h"
#import <HelloSDK/HelloSDK.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self testHelloLib];
    [self testHelloSDK];

}

- (void)testHelloSDK {
    BarSDK *bar = [[BarSDK alloc] init];
    [bar bar];
    
    FooSDK *foo = [[FooSDK alloc] init];
    [foo foo];
    [foo getLoveImage];
    
    [self.view foo];
}

- (void)testHelloLib {
    HelloLib *hello = [[HelloLib alloc] init];
    [hello hello];
    
    FooLib *foo = [[FooLib alloc] init];
    [foo foo];
    [foo getLoveImage];
    
    [self.view bar];
}


@end
