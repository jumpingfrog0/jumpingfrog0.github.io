//
//  StatusBarHiddenRemoveWayParentViewController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/22.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenRemoveWayParentViewController: UIViewController {
    
    var childController: StatusBarHiddenRemoveWayChildController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dismissButton = UIButton(frame: CGRectMake(30, 30, 100, 100))
        dismissButton.setTitle("dismiss", forState: .Normal)
        dismissButton.addTarget(self, action: "dismiss", forControlEvents: .TouchUpInside)
        view.addSubview(dismissButton)
        
        childController = StatusBarHiddenRemoveWayChildController.fromStoryboard("Main")
        addChildViewController(childController!)
        view.addSubview(childController!.view)
    }
    
    func dismiss() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func childViewControllerForStatusBarHidden() -> UIViewController? {
        return childController
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return false
    }

}
