//
//  StatusBarHiddenSwizzlingParentController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/24.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenSwizzlingParentController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if navigationController?.navigationBar == nil {
            let dismissButton = UIButton(frame: CGRectMake(30, 30, 100, 30))
            dismissButton.setTitle("dismiss", forState: .Normal)
            dismissButton.addTarget(self, action: "dismiss", forControlEvents: .TouchUpInside)
            view.addSubview(dismissButton)
        }
        
        let childController = StatusBarHiddenSwizzlingChildController.fromStoryboard("Main")
        addChildViewController(childController)
        view.addSubview(childController.view)
    }
    
    // warning: 
    // override `prefersStatusBarHidden` in `ParentViewController` as possible
    
//    override func prefersStatusBarHidden() -> Bool {
//        return false
//    }
    
    func dismiss() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    deinit {
        print("parent -- deinit")
    }
}
