//
//  StatusBarHiddenChildController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/20.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenChildController: UIViewController {
    
    
    @IBOutlet weak var pushButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        if navigationController?.navigationBar == nil {
            
            let dismissButton = UIButton(frame: CGRectMake(30, 30, 100, 30))
            dismissButton.setTitle("dismiss", forState: .Normal)
            dismissButton.addTarget(self, action: "dismiss", forControlEvents: .TouchUpInside)
            view.addSubview(dismissButton)
            
            let removeButton = UIButton(frame: CGRectMake(5, 80, 400, 30))
            removeButton.setTitle("remove, not handle when remove", forState: .Normal)
            removeButton.addTarget(self, action: "remove", forControlEvents: .TouchUpInside)
            view.addSubview(removeButton)
            
            pushButton.hidden = true
        }
    }
    
    // can hide status bar, because its parent controller determine status bar hidden giving it to handle

    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
    // the way of presenting view controller modally can recover the status bar when dimiss view controller
    
    func dismiss() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // the way of removing view controller will not recover the status bar
    
    func remove() {
        view.removeFromSuperview()
        removeFromParentViewController()
//        setNeedsStatusBarAppearanceUpdate()
    }

}
