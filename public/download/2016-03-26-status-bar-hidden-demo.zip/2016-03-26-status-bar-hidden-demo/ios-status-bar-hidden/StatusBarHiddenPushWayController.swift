//
//  StatusBarHiddenPushWayController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/20.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenPushWayController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // the way of pushing view controller can recover the status bar when pop view controller
        
        let parentController = StatusBarHiddenParentController.fromStoryboard("Main")
        self.navigationController?.pushViewController(parentController, animated: true)
    }

}
