//
//  StatusBarHiddenNotEffectiveChildController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/20.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenNotEffectiveChildController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    // can not hide status bar, this code don't work
    // because this controller is as `StatusBarHiddenNotEffectiveController` child controller

    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
}
