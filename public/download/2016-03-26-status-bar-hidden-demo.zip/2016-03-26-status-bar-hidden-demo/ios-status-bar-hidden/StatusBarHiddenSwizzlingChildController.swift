//
//  StatusBarHiddenSwizzlingChildController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/25.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenSwizzlingChildController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if navigationController?.navigationBar == nil {
            let dismissButton = UIButton(frame: CGRectMake(30, 30, 100, 30))
            dismissButton.setTitle("dismiss", forState: .Normal)
            dismissButton.addTarget(self, action: "dismiss", forControlEvents: .TouchUpInside)
            view.addSubview(dismissButton)
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        guard let parentViewController = parentViewController else {
            return
        }
        
        if parentViewController.respondsToSelector("setNeedsStatusBarAppearanceUpdate") {
            
            hookPrefersStatusBarHidden(parentViewController)
        }
    }
    
    func hookPrefersStatusBarHidden(parentViewController: UIViewController) {
        
        let originalSelector = Selector("prefersStatusBarHidden")
        let swizzledSelector = Selector("hook_prefersStatusBarHidden")
        
        let originalMethod = class_getInstanceMethod(parentViewController.dynamicType, originalSelector)
        let swizzledMethod = class_getInstanceMethod(self.dynamicType, swizzledSelector)
        
        let didAddMethod: Bool = class_addMethod(parentViewController.dynamicType,
            originalSelector,
            method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod))
        
        if didAddMethod {
            class_replaceMethod(self.dynamicType,
                swizzledSelector,
                method_getImplementation(originalMethod),
                method_getTypeEncoding(originalMethod))
        } else {
            method_exchangeImplementations(originalMethod, swizzledMethod)
        }
        
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
        
            parentViewController.prefersStatusBarHidden()
            parentViewController.setNeedsStatusBarAppearanceUpdate()
        }
    }
    
    // must recover the hook when view will disappear
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        guard let parentViewController = parentViewController else {
            return
        }
        
        if parentViewController.respondsToSelector("setNeedsStatusBarAppearanceUpdate") {
            
            hookPrefersStatusBarHidden(parentViewController)
        }
        
    }
    
    func hook_prefersStatusBarHidden() -> Bool {
        return true
    }
    
    func dismiss() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func remove() {
        view.removeFromSuperview()
        removeFromParentViewController()
    }
    
    deinit {
        print("child -- deinit")
    }
}
