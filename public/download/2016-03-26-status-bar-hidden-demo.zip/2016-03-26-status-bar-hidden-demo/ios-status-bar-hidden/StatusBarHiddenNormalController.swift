//
//  StatusBarHiddenNormalController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/20.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenNormalController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    // can hide status bar normally
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }

}
