//
//  StatusBarHiddenNotEffectiveController.swift
//  ios-status-bar-hidden
//
//  Created by sheldon on 16/3/20.
//  Copyright © 2016年 jumpingfrog0. All rights reserved.
//

import UIKit

class StatusBarHiddenNotEffectiveController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let childVc = StatusBarHiddenNotEffectiveChildController.fromStoryboard("Main")
        addChildViewController(childVc)
        view.addSubview(childVc.view)
    }
    

}

extension UIViewController {
    
    class func fromStoryboard(name: String) -> Self {
        let object: AnyObject = UIStoryboard(name: name, bundle: nil).instantiateViewControllerWithIdentifier(String(self))
        return objcast(object)
    }
    
    class func objcast<T>(obj: AnyObject) -> T {
        return obj as! T
    }

}